VCP279
======

David Herscher – The purpose of this project was to build a functioning web application to be used for the purposes of rental creation, administration and management. My focus for this endeavor was to provide a flexible, portable and accessible solution to this problem. I wanted to use reliable, open and standards compliant technologies, which would provide a flexible foundation to be deployed on top of the most basic set hardware and software requirements. Most importantly, with this project I set out to push myself to learn something new. This body of code is not only the culmination of all that I have learned thus far. It represents the application of that knowledge towards building a foundation upon which my learning continues far into the future. 
