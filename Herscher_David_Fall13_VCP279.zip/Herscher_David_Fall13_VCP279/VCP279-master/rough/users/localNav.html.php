
	<div class="sideNav">
		<ul id="userAdminNav">
			<li>
				<a href="?listUsers"><h3>List Users</h3></a>
			</li>
			<li>
				<a href="?addUser"><h3>Add User</h3></a>
			</li>
		</ul>
	</div>

