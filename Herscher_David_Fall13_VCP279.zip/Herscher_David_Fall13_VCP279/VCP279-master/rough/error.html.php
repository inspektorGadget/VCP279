<div class="content">
	<p><?php echo $error; ?></p>
	<p>
		<a href="<?php echo $_SERVER['DOCUMENT_ROOT'] . '/VCP279/rough/';?>">Return</a>
	</p>
</div>
	

