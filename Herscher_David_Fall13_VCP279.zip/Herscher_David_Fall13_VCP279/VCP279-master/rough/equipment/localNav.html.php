
	<div class="sideNav">
		<ul id="equipmentAdminNav">
			<li>
				<a href="?listEquipment"><h3>List Equipment</h3></a>
			</li>
			<li>
				<a href="?addEquipment"><h3>Add Equipment</h3></a>
			</li>
		</ul>
	</div>

