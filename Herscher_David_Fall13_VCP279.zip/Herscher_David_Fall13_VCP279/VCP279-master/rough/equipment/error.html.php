<div class="content">
	<p><?php echo $error; ?></p>
</div>
	

