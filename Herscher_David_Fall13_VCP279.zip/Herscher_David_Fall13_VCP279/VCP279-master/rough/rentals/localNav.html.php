
	<div class="sideNav">
		<ul id="rentalAdminNav">
			<li>
				<a href="?listRentals"><h3>List Rentals</h3></a>
			</li>
			<li>
				<a href="?addRental"><h3>Add Rental</h3></a>
			</li>
		</ul>
	</div>

