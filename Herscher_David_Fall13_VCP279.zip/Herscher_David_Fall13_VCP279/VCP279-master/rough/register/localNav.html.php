<div class="sideNav">
		<ul id="userProfileNav">
			<li>
				<a href="?editProfile"><h3>Edit Profile</h3></a>
			</li>
			<li>
				<a href="?changePassword"><h3>Change Password</h3></a>
			</li>
		</ul>
	</div>
